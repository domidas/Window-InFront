#Window InFront, a program by f-poke
#Copyright 2021 f-poke
#www.github.com/f-poke
$host.UI.RawUI.WindowTitle = "Window InFront Installer"
echo "f-poke's Window InFront, All Rights Reserved."
echo .
echo "Downloading AHK Installer..."
echo .
cd $home
$download = '.\Downloads\ahk-install.exe'
$confirm = Test-Path $download
If ($confirm -eq $true) {
    Write-Host 'Installer Already Exists!'
}
If(-not $confirm) {
    Start-BitsTransfer -Source 'https://www.autohotkey.com/download/ahk-install.exe' -Destination '.\Downloads\'
    Write-Host 'Installer Successfully Downloaded'
}
echo "Installing AHK..."
echo .
cd .\Downloads\
Start-Process ahk-install.exe -ArgumentList "/s" -Wait
echo "Creating Window InFront script..."
echo .
cd $env:APPDATA
cd '.\Microsoft\Windows\Start Menu\Programs\Startup'
$ahk = '.\alwaysontop.ahk'
$sstatus = Test-Path $ahk
If ($sstatus -eq $true) {
    Write-Host 'Script Already Exists!'
}
If (-not $sstatus) {
    New-Item $env:APPDATA\Microsoft\Windows\Start` Menu\Programs\Startup\alwaysontop.ahk -ItemType file -Value "^SPACE::  Winset, Alwaysontop, , A"
    cd $env:APPDATA\Microsoft\Windows\Start` Menu\Programs\Startup\
}
echo "You must restart for changes to take effect."
$confirmation = Read-Host "Reboot Machine Now? [y/n]"
if ($confirmation -eq 'y') {
    Restart-Computer
}
if ($confirmation -eq 'n') {
    exit
}