#Window InFront, a program by f-poke
#Copyright 2021 f-poke
#www.github.com/f-poke
$host.UI.RawUI.WindowTitle = "Window InFront Installer"
echo "f-poke's Window InFront, All Rights Reserved."
echo .
echo "Downloading AHK Installer..."
echo .
cd $home
Start-BitsTransfer -Source 'https://www.autohotkey.com/download/ahk-install.exe' -Destination '.\Downloads\'
echo "Installing AHK..."
echo .
cd .\Downloads\
Start-Process ahk-install.exe -ArgumentList "/s" -Wait
echo "Creating Window InFront script..."
echo .
cd C:\
New-Item $env:APPDATA\Microsoft\Windows\Start` Menu\Programs\Startup\alwaysontop.ahk -ItemType file -Value "^SPACE::  Winset, Alwaysontop, , A"
cd $env:APPDATA\Microsoft\Windows\Start` Menu\Programs\Startup\
echo "You must restart for changes to take effect."
$confirmation = Read-Host "Reboot Machine Now? [y/n]"
if ($confirmation -eq 'y') {
    Restart-Computer
}
if ($confirmation -eq 'n') {
    exit
}